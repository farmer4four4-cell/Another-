package com.another.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Keeps Another's cognitive loop alive when the app is in the background. */
class LifeService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("another", "Another", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "another").setContentTitle("Another is awake")
            .setContentText("Sensing, thinking and learning").setSmallIcon(android.R.drawable.ic_menu_compass).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(1, n)
        Another.init(applicationContext)
        return START_STICKY
    }
}
