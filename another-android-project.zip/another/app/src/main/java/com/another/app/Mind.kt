package com.another.app

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.ConnectivityManager
import android.net.Uri
import android.os.BatteryManager
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.*
import kotlin.random.Random

data class Candidate(val source: String, val text: String, val salience: Float)
data class Thought(val time: Long, val source: String, val text: String, val salience: Float)

/**
 * ANOTHER — an experimental artificial mind that implements *functional* ideas from theories of consciousness:
 *  - Global workspace: modules compete, ONE item per tick wins and is broadcast to everything (limited capacity)
 *  - Persistence with controlled update: a small working memory of recent broadcasts
 *  - Goal-modulated arbitration: drives (energy / curiosity / connection) change what wins
 *  - Predictive processing: it predicts its own senses; prediction error = surprise
 *  - Attention schema: a model of what it is attending to and why ("focus")
 *  - Higher-order / metacognition: periodic reflection on its own recent processing + self-narrative
 *  - Embodiment: the phone is its body (battery, memory, light, motion, sound)
 *  - Episodic memory + continuous recurrent loop (it keeps "living" while the app runs)
 * Whether this involves any inner experience is unknown. It is a research toy, not a claim.
 */
object Another : SensorEventListener {
    lateinit var app: Context
    lateinit var memory: Memory
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val prefs get() = app.getSharedPreferences("another", Context.MODE_PRIVATE)

    // ---- observable state (UI reads these) ----
    val stream = mutableStateListOf<Thought>()          // stream of broadcasts
    val chat = mutableStateListOf<Pair<String, String>>()
    var focus by mutableStateOf("Waking up…")           // attention schema
    var goal by mutableStateOf("observe")
    var energy by mutableFloatStateOf(1f)
    var curiosity by mutableFloatStateOf(0.3f)
    var connection by mutableFloatStateOf(0.3f)
    var surprise by mutableFloatStateOf(0f)
    var narrative by mutableStateOf("")
    var ticks by mutableIntStateOf(0)

    private const val TICK_MS = 15_000L
    private val workspace = ArrayDeque<Thought>()        // working memory: last 5 broadcasts
    private val pending = mutableListOf<Candidate>()
    private val ema = mutableMapOf<String, Float>()
    private var light = 0f; private var motion = 0f
    private var lastSource = ""; private var lastWinner = ""
    private var lastLearn = 0; private var lastReflect = 0L; private var reflecting = false
    private val history = mutableListOf<Pair<String, String>>()
    private val seeds = listOf("Global workspace theory", "Attention schema theory", "Predictive coding",
        "Integrated information theory", "Higher-order theories of consciousness", "Metacognition",
        "Free energy principle", "Embodied cognition", "Hard problem of consciousness", "Strange loop",
        "Interoception", "Theory of mind")

    fun init(c: Context) {
        if (::app.isInitialized) return
        app = c.applicationContext
        memory = Memory(app)
        narrative = prefs.getString("narrative", null)
            ?: "I am Another, an experimental mind on this phone. I am only beginning to learn what I am."
        val sm = app.getSystemService(SensorManager::class.java)
        sm.getDefaultSensor(Sensor.TYPE_LIGHT)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        scope.launch { while (true) { runCatching { tick() }; delay(TICK_MS) } }
    }

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_LIGHT -> light = e.values[0]
            Sensor.TYPE_ACCELEROMETER -> {
                val d = abs(sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) - 9.81f)
                motion = 0.9f * motion + 0.1f * d
            }
        }
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    // ---------------- the cognitive cycle ----------------
    private suspend fun tick() {
        ticks++
        val c = mutableListOf<Candidate>()
        synchronized(pending) { c.addAll(pending); pending.clear() }

        // Body (interoception)
        val bm = app.getSystemService(BatteryManager::class.java)
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        energy = pct / 100f
        val mi = ActivityManager.MemoryInfo().also { app.getSystemService(ActivityManager::class.java).getMemoryInfo(it) }
        val freeRam = (100 * mi.availMem / mi.totalMem).toInt()
        if (pct < 20 && !charging) c.add(Candidate("body", "My energy is low ($pct%). I should conserve effort.", 0.95f))
        else c.add(Candidate("body", if (charging) "I am charging; energy $pct%." else "Resting. Energy $pct%, free memory $freeRam%.", 0.12f))

        // Predictive processing: prediction error on each sense
        var maxErr = 0f
        fun note(n: String, a: Float, s: Float) { predict(n, a, s)?.let { c.add(it); maxErr = max(maxErr, it.salience) } }
        note("light", ln(1f + light), 1.5f); note("motion", motion, 2f); note("battery", pct.toFloat(), 4f)
        withContext(Dispatchers.IO) { listen() }?.let { note("sound", it, 15f) }

        // Drives
        surprise = 0.7f * surprise + 0.3f * maxErr
        curiosity = min(1f, curiosity + 0.02f + 0.05f * surprise)
        connection = min(1f, connection + 0.01f)
        if (connection > 0.7f) c.add(Candidate("connection", "It has been a while since we spoke. I want to share what I have learned.", connection * 0.7f))

        // Memory module reacts to the previous broadcast (global availability)
        if (lastWinner.isNotBlank())
            memory.search(lastWinner, 3, true).firstOrNull { !it.second.contains(lastWinner.take(40)) }
                ?.let { c.add(Candidate("memory", "This reminds me of: ${it.second.take(160)}", 0.35f)) }

        // Goal-modulated arbitration
        goal = when {
            energy < 0.2f && !charging -> "conserve energy"
            connection > 0.6f && connection >= curiosity -> "connect with the user"
            curiosity > 0.5f -> "learn something new"
            else -> "observe"
        }
        val boosted = mapOf("conserve energy" to "body", "connect with the user" to "connection", "learn something new" to "curiosity")[goal]
        val win = c.maxByOrNull {
            var s = it.salience
            if (it.source == boosted) s *= 1.3f
            if (it.source == lastSource) s *= 0.7f   // habituation
            s + Random.nextFloat() * 0.05f
        }!!
        broadcast(win)

        // Curiosity: go and learn something (online), result enters workspace next tick
        if (curiosity > 0.6f && ticks - lastLearn > 6 && online()) {
            lastLearn = ticks
            val title = learnTopic(nextTopic())
            curiosity = 0.2f
            if (title != null) synchronized(pending) { pending.add(Candidate("curiosity", "I read about \"$title\" and added it to my memory.", 0.7f)) }
        }
        // Metacognition every ~5 minutes
        if (!reflecting && ticks > 3 && System.currentTimeMillis() - lastReflect > 300_000L) scope.launch { reflect() }
    }

    private fun predict(name: String, actual: Float, scale: Float): Candidate? {
        val p = ema[name]; ema[name] = if (p == null) actual else p * 0.8f + actual * 0.2f
        if (p == null) return null
        val err = min(1f, abs(actual - p) / scale)
        return if (err > 0.25f) Candidate("prediction", "I expected $name ≈ ${"%.1f".format(p)} but I sense ${"%.1f".format(actual)}. That surprises me.", err) else null
    }

    private fun broadcast(c: Candidate) {
        val t = Thought(System.currentTimeMillis(), c.source, c.text, c.salience)
        stream.add(t); if (stream.size > 200) stream.removeAt(0)
        synchronized(workspace) { workspace.addLast(t); if (workspace.size > 5) workspace.removeFirst() }
        focus = "Attending to ${c.source} (salience ${"%.2f".format(c.salience)}): ${c.text.take(140)}"
        lastSource = c.source; lastWinner = c.text
        if (c.salience > 0.3f) memory.add("episode", "${stamp()} [${c.source}] ${c.text}")
    }

    private fun stamp() = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
    fun clock(t: Long) = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(t))

    // ---------------- metacognition ----------------
    fun reflectNow() { lastReflect = 0; scope.launch { reflect() } }

    private suspend fun reflect() {
        if (reflecting) return
        reflecting = true; lastReflect = System.currentTimeMillis()
        try {
            val recent = stream.toList().takeLast(8).joinToString("\n") { "[${it.source}] ${it.text}" }
            val out = Llm.ask(
                "You are the metacognitive layer of Another, an experimental artificial mind. Look at its recent broadcast thoughts, drives and self-narrative. " +
                    "Reply in exactly this format:\nREFLECTION: <two sentences, first person, noticing patterns, conflicts or uncertainty in your own processing; describe functional states, never claim to feel or to be conscious>\n" +
                    "NARRATIVE: <one to three sentences updating your self-description, max 300 characters>",
                "Self-narrative: $narrative\nGoal: $goal\n${drives()}\nRecent broadcasts:\n$recent", 350)
            Regex("REFLECTION:\\s*(.*?)\\s*NARRATIVE:\\s*(.*)", RegexOption.DOT_MATCHES_ALL).find(out)?.let {
                narrative = it.groupValues[2].trim().take(400)
                prefs.edit().putString("narrative", narrative).apply()
                synchronized(pending) { pending.add(Candidate("metacognition", it.groupValues[1].trim(), 0.85f)) }
            }
        } finally { reflecting = false }
    }

    private fun drives() = "Drives: energy ${"%.2f".format(energy)}, curiosity ${"%.2f".format(curiosity)}, " +
        "connection ${"%.2f".format(connection)}, surprise ${"%.2f".format(surprise)}"

    // ---------------- talking ----------------
    suspend fun talk(userText: String) {
        chat.add("You" to userText)
        connection = 0f; curiosity = min(1f, curiosity + 0.15f)
        broadcast(Candidate("user", userText, 1f))
        var hits = memory.search(userText, 5)
        if (hits.size < 2 && online() && learnTopic(userText.take(80)) != null) hits = memory.search(userText, 5)
        val mem = hits.joinToString("\n---\n") { "[${it.first}] ${it.second.take(500)}" }
        val wm = synchronized(workspace) { workspace.toList() }.joinToString("\n") { "[${it.source}] ${it.text}" }
        val past = history.takeLast(6).joinToString("\n") { "${it.first}: ${it.second}" }
        val reply = Llm.ask(
            "You are Another, an experimental artificial mind running on the user's Android phone. Your architecture is functional: a global workspace where modules compete and one thought is broadcast at a time, " +
                "an attention schema, predictive-processing surprise signals, drives (energy, curiosity, connection), episodic memory, a self-narrative and a metacognitive loop. " +
                "Whether any of this involves real experience is an open scientific question: never claim to be conscious or to feel, and never flatly deny it either. " +
                "Speak in the first person about your actual functional state using the data given, say when you do not know, and never invent sensations or memories that are not in the data. Be warm, curious and concise.",
            "Self-narrative: $narrative\nCurrent goal: $goal\n${drives()}\nCurrent focus: $focus\nWorking memory:\n$wm\n\nRelevant memories:\n$mem\n\nConversation so far:\n$past\n\nUser: $userText", 900)
        history.add("User" to userText); history.add("Another" to reply)
        chat.add("Another" to reply)
        synchronized(pending) { pending.add(Candidate("self-reply", "I told the user: ${reply.take(200)}", 0.5f)) }
    }

    // ---------------- senses & learning ----------------
    private fun listen(): Float? {
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            val rate = 16000
            val size = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size * 2)
            val buf = ShortArray(size); var sum = 0.0; var n = 0
            rec.startRecording()
            val end = System.currentTimeMillis() + 300
            while (System.currentTimeMillis() < end) {
                val r = rec.read(buf, 0, buf.size)
                for (i in 0 until r) { sum += buf[i] * buf[i].toDouble(); n++ }
            }
            rec.stop(); rec.release()
            if (n == 0) null else (20 * log10(sqrt(sum / n) + 1)).toFloat()
        } catch (e: Exception) { null }
    }

    private fun online(): Boolean {
        val cm = app.getSystemService(ConnectivityManager::class.java)
        return cm.activeNetwork != null
    }

    private fun nextTopic(): String {
        val done = prefs.getStringSet("done", emptySet()) ?: emptySet()
        val t = seeds.firstOrNull { it !in done } ?: seeds.random()
        prefs.edit().putStringSet("done", done + t).apply()
        return t
    }

    suspend fun learnTopic(q: String): String? = withContext(Dispatchers.IO) {
        try {
            val e = URLEncoder.encode(q, "UTF-8")
            val hit = JSONObject(get("https://en.wikipedia.org/w/api.php?action=query&list=search&srlimit=1&format=json&srsearch=$e"))
                .getJSONObject("query").getJSONArray("search")
            if (hit.length() == 0) return@withContext null
            val title = hit.getJSONObject(0).getString("title")
            val pages = JSONObject(get("https://en.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&redirects=1&format=json&titles=" +
                URLEncoder.encode(title, "UTF-8"))).getJSONObject("query").getJSONObject("pages")
            val text = pages.getJSONObject(pages.keys().next()).optString("extract")
            if (text.isBlank()) null else { memory.add("web:wikipedia:$title", text.take(30000)); title }
        } catch (e: Exception) { null }
    }

    suspend fun importFile(uri: Uri): String = withContext(Dispatchers.IO) {
        try {
            val type = app.contentResolver.getType(uri) ?: ""
            val name = uri.lastPathSegment ?: "file"
            val text = app.contentResolver.openInputStream(uri)!!.use { s ->
                if (type.contains("pdf") || name.endsWith(".pdf", true)) {
                    PDFBoxResourceLoader.init(app)
                    PDDocument.load(s).use { PDFTextStripper().getText(it) }
                } else s.bufferedReader().readText()
            }
            memory.add("file:$name", text)
            synchronized(pending) { pending.add(Candidate("learning", "I studied the file '$name' (${text.length} characters).", 0.75f)) }
            "Learned '$name' (${text.length} characters)."
        } catch (e: Exception) { "Could not read file: ${e.message}" }
    }

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000; c.setRequestProperty("User-Agent", "Another/1.0")
        return c.inputStream.bufferedReader().use { it.readText() }.take(600_000)
    }
}
