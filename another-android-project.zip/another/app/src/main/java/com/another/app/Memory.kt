package com.another.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.io.File

/** Long-term memory on the phone: "episode" entries (its own life) and knowledge from files/web. */
class Memory(ctx: Context) {
    private val file = File(ctx.filesDir, "memory.jsonl")
    private val items = mutableListOf<Pair<String, String>>()
    var count by mutableIntStateOf(0)

    init {
        if (file.exists()) file.forEachLine { line ->
            runCatching { JSONObject(line) }.getOrNull()?.let { items.add(it.getString("s") to it.getString("t")) }
        }
        count = items.size
    }

    private fun line(p: Pair<String, String>) = JSONObject().put("s", p.first).put("t", p.second).toString() + "\n"

    @Synchronized fun add(source: String, text: String) {
        text.trim().chunked(800).filter { it.isNotBlank() }.forEach { items.add(source to it); file.appendText(line(source to it)) }
        if (items.size > 5000) { // forget the oldest episodes first
            var drop = 500
            val it = items.iterator()
            while (it.hasNext() && drop > 0) if (it.next().first == "episode") { it.remove(); drop-- }
            file.writeText(items.joinToString("") { line(it) })
        }
        count = items.size
    }

    /** episodesOnly: true = only own episodes, false = only learned knowledge, null = both. */
    @Synchronized fun search(q: String, k: Int = 5, episodesOnly: Boolean? = null): List<Pair<String, String>> {
        val words = q.lowercase().split(Regex("\\W+")).filter { it.length > 2 }.distinct()
        if (words.isEmpty()) return emptyList()
        return items.asSequence()
            .filter { episodesOnly == null || (it.first == "episode") == episodesOnly }
            .map { p -> val l = p.second.lowercase(); p to words.count { w -> l.contains(w) } }
            .filter { it.second > 0 }.sortedByDescending { it.second }.take(k).map { it.first }.toList()
    }
}
