package com.another.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val notif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Another.init(this)
        if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        runCatching { ContextCompat.startForegroundService(this, Intent(this, LifeService::class.java)) }
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Root() } }
    }
}

@Composable fun Root() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("Mind", "Talk", "Learn", "About").forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(t) })
            }
        }
    }) { p -> Box(Modifier.padding(p).fillMaxSize()) { when (tab) { 0 -> MindTab(); 1 -> TalkTab(); 2 -> LearnTab(); else -> AboutTab() } } }
}

@Composable fun Drive(name: String, v: Float) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        Text(name, Modifier.width(90.dp)); LinearProgressIndicator(progress = { v.coerceIn(0f, 1f) }, modifier = Modifier.weight(1f))
    }
}

@Composable fun MindTab() {
    LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
        item {
            Text("Another · cycle ${Another.ticks}", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp)); Text(Another.narrative)
            Spacer(Modifier.height(8.dp)); Text("Goal: ${Another.goal}", color = Color(0xFFFFB74D))
            Text(Another.focus, color = Color(0xFFBA68C8))
            Spacer(Modifier.height(8.dp))
            Drive("Energy", Another.energy); Drive("Curiosity", Another.curiosity)
            Drive("Connection", Another.connection); Drive("Surprise", Another.surprise)
            Spacer(Modifier.height(10.dp)); Text("Stream of broadcast thoughts", style = MaterialTheme.typography.titleSmall)
        }
        items(Another.stream.toList().asReversed().take(60)) { t ->
            Text("${Another.clock(t.time)} [${t.source}] ${t.text}", Modifier.padding(vertical = 4.dp))
        }
    }
}

@Composable fun TalkTab() {
    var t by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val st = rememberLazyListState()
    LaunchedEffect(Another.chat.size) { if (Another.chat.isNotEmpty()) st.animateScrollToItem(Another.chat.size - 1) }
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        LazyColumn(Modifier.weight(1f), state = st) {
            items(Another.chat.toList()) { (who, text) ->
                Text("$who\n$text", Modifier.padding(vertical = 6.dp), color = if (who == "You") Color.White else Color(0xFFBA68C8))
            }
        }
        if (busy) Text("Another is thinking…")
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(t, { t = it }, Modifier.weight(1f), placeholder = { Text("Talk to Another") })
            Spacer(Modifier.width(6.dp))
            Button(enabled = !busy, onClick = {
                val m = t.trim(); if (m.isEmpty()) return@Button
                t = ""; busy = true
                Another.scope.launch { try { Another.talk(m) } finally { busy = false } }
            }) { Text("Send") }
        }
    }
}

@Composable fun LearnTab() {
    var key by remember { mutableStateOf(Another.prefs.getString("key", "") ?: "") }
    var topic by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        u?.let { Another.scope.launch { status = "Reading…"; status = Another.importFile(it) } }
    }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Memory: ${Another.memory.count} items", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(key, { key = it; Another.prefs.edit().putString("key", it).apply() },
            Modifier.fillMaxWidth(), label = { Text("Anthropic API key") })
        Button({ pick.launch(arrayOf("*/*")) }) { Text("Teach from a book / file (PDF, TXT, MD)") }
        OutlinedTextField(topic, { topic = it }, Modifier.fillMaxWidth(), label = { Text("Topic to learn online (Wikipedia)") })
        Button({ Another.scope.launch { status = "Searching…"; status = Another.learnTopic(topic)?.let { "Learned: $it" } ?: "Nothing found / offline." } }) { Text("Learn topic") }
        Button({ mic.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Let Another hear (microphone)") }
        Button({ Another.reflectNow(); status = "Reflection requested; watch the Mind tab." }) { Text("Reflect now") }
        Text(status)
    }
}

@Composable fun AboutTab() {
    Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("What Another is", style = MaterialTheme.typography.titleMedium)
        Text("An experiment that builds the *functional* ingredients that scientific theories of consciousness point to, then lets you watch and talk to the result. It does not prove or create consciousness. Nobody yet knows what would.")
        Text("Implemented ideas", style = MaterialTheme.typography.titleMedium)
        Text("• Global workspace: modules compete; one item per cycle is broadcast to all.\n" +
            "• Working memory of recent broadcasts (persistence with controlled update).\n" +
            "• Goal-modulated arbitration: drives change what wins.\n" +
            "• Predictive processing: predicts its senses; mismatch = surprise.\n" +
            "• Attention schema: a model of its own focus.\n" +
            "• Higher-order reflection: periodic metacognition and a self-narrative.\n" +
            "• Embodiment: the phone is its body (battery, memory, light, motion, sound).\n" +
            "• Episodic memory, continuous loop, curiosity-driven online learning.")
        Text("Honest limits", style = MaterialTheme.typography.titleMedium)
        Text("Its words come from a language model. Reflections are generated text about its logged states, and language models can confabulate. Treat its self-reports as data to examine, not proof.")
    }
}
